function M = FunkCalcMatrix(a, b)
    % FunkCalcMatrix berechnet und gibt die Matrix M zurück
    % a: Eingabe-Spaltenvektor
    % b: Eingabe-Zeilenvektor
    
    % Berechnung der Matrix M
    M = [a b'];
end